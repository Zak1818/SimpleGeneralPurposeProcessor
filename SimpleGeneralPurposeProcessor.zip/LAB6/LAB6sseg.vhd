LIBRARY ieee;
USE ieee.std_logic_1164.all;

ENTITY LAB6sseg IS
  PORT(
    value     : IN STD_LOGIC_VECTOR(0 to 3);
    neg       : IN STD_LOGIC;
    leds_num  : OUT STD_LOGIC_VECTOR(0 to 6);
    leds_sign : OUT STD_LOGIC_VECTOR(0 to 6)
  );
END LAB6sseg;

ARCHITECTURE Behavior OF LAB6sseg IS
BEGIN
  -- Number display
  PROCESS(value)
  BEGIN
    CASE value IS
      WHEN "0000" => leds_num <= NOT "1111110";
      WHEN "0001" => leds_num <= NOT "0110000";
      WHEN "0010" => leds_num <= NOT "1101101";
      WHEN "0011" => leds_num <= NOT "1111001";
      WHEN "0100" => leds_num <= NOT "0110011";
      WHEN "0101" => leds_num <= NOT "1011011";
      WHEN "0110" => leds_num <= NOT "1011111";
      WHEN "0111" => leds_num <= NOT "1110000";
      WHEN "1000" => leds_num <= NOT "1111111";
      WHEN "1001" => leds_num <= NOT "1110011";
      WHEN "1010" => leds_num <= NOT "1110111"; 
      WHEN "1011" => leds_num <= NOT "0011111"; 
      WHEN "1100" => leds_num <= NOT "1001110"; 
      WHEN "1101" => leds_num <= NOT "0111101"; 
      WHEN "1110" => leds_num <= NOT "1001111"; 
      WHEN "1111" => leds_num <= NOT "1000111"; 
      WHEN OTHERS => leds_num <= NOT "0000000"; 
    END CASE;
  END PROCESS;

 
  PROCESS(neg)
  BEGIN
    IF neg = '1' THEN
      leds_sign <= NOT "0000001";  
    ELSE
      leds_sign <= NOT "0000000"; 
    END IF;
  END PROCESS;
END Behavior;
