library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity ALU2 is
    port(
        Clock      : in  std_logic;
        A, B       : in  unsigned(7 downto 0);
        student_id : in  unsigned(3 downto 0);
        OP         : in  unsigned(15 downto 0);
        Neg        : out std_logic;
        R1         : out unsigned(3 downto 0);
        R2         : out unsigned(3 downto 0)
    );
end ALU2;

architecture calculation of ALU2 is
    signal Reg1, Reg2, Result : unsigned(7 downto 0) := (others => '0');
begin

    Reg1 <= A;
    Reg2 <= B;

    process(Clock, OP)
        variable temp : unsigned(8 downto 0);
    begin
        if rising_edge(Clock) then

            case OP is

                when "0000000000000001" =>
                    temp := ("0" & Reg1) - ("0" & Reg2);
                    Result <= temp(7 downto 0);
                    Neg <= temp(8);

                when "0000000000000010" =>
                    Result <= not Reg2 + 1;
                    Neg <= '0';

                when "0000000000000100" =>
                    Result <= Reg1(7 downto 4) & Reg2(3 downto 0);
                    Neg <= '0';

                when "0000000000001000" =>
                    Result <= (others => '0');
                    Neg <= '0';

                when "0000000000010000" =>
                    Result <= Reg2 - 5;
                    Neg <= '0';

                when "0000000000100000" =>
                    Result <= Reg1(0) & Reg1(1) & Reg1(2) & Reg1(3) &
                              Reg1(4) & Reg1(5) & Reg1(6) & Reg1(7);
                    Neg <= '0';

                when "0000000001000000" =>
                    Result <= Reg2(4 downto 0) & "111";
                    Neg <= '0';

                when "0000000010000000" =>
                    Result <= Reg1 + 3;
                    Neg <= '0';

                when "0000000100000000" =>
                    Result <= not Reg2;
                    Neg <= '0';

                when others =>
                    Result <= (others => '0');
                    Neg <= '0';

            end case;
        end if;
    end process;

    R1 <= Result(3 downto 0);
    R2 <= Result(7 downto 4);

end calculation;