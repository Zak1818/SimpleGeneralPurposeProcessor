library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity LAB6alu is
    port(
        Clock      : in  std_logic;                    -- input clock signal
        A, B       : in  unsigned(7 downto 0);         -- 8-bit inputs from latches A and B
        student_id : in  unsigned(3 downto 0);         -- 4-bit student ID (unused)
        OP         : in  unsigned(15 downto 0);        -- 16-bit selector from Operation Decoder
        Neg        : out std_logic;                    -- negative result flag
        R1         : out unsigned(3 downto 0);         -- lower 4 bits of 8-bit result
        R2         : out unsigned(3 downto 0)          -- upper 4 bits of 8-bit result
    );
end LAB6alu;

architecture calculation of LAB6alu is
    -- temporary internal signal declarations
    signal Reg1, Reg2, Result : unsigned(7 downto 0) := (others => '0');
    signal Reg4               : unsigned(7 downto 0) := (others => '0');
begin

    -- temporarily store A and B
    Reg1 <= A;
    Reg2 <= B;

    process(Clock, OP)
        variable temp : unsigned(8 downto 0);
    begin
        if rising_edge(Clock) then          -- do the calculation on positive edge

            case OP is

                when "0000000000000001" =>      -- Do Addition for Reg1 and Reg2
                    temp := ("0" & Reg1) + ("0" & Reg2);
                    Result <= temp(7 downto 0);
                    Neg <= '0';

                when "0000000000000010" =>      -- Do Subtraction, set Neg bit if required
                    temp := ("0" & Reg1) - ("0" & Reg2);

                    if temp(8) = '1' then
                        Neg <= '1';
                        Result <= not temp(7 downto 0) + 1;   -- two's complement
                    else
                        Neg <= '0';
                        Result <= temp(7 downto 0);
                    end if;

                when "0000000000000100" =>      -- Do Boolean Inverse
                    Result <= not Reg1;
                    Neg <= '0';

                when "0000000000001000" =>      -- Do Boolean NAND
                    Result <= not(Reg1 and Reg2);
                    Neg <= '0';

                when "0000000000010000" =>      -- Do Boolean NOR
                    Result <= not(Reg1 or Reg2);
                    Neg <= '0';

                when "0000000000100000" =>      -- Do Boolean AND
                    Result <= Reg1 and Reg2;
                    Neg <= '0';

                when "0000000001000000" =>      -- Do Boolean OR
                    Result <= Reg1 or Reg2;
                    Neg <= '0';

                when "0000000010000000" =>      -- Do Boolean XOR
                    Result <= Reg1 xor Reg2;
                    Neg <= '0';

                when "0000000100000000" =>      -- Do Boolean XNOR
                    Result <= not(Reg1 xor Reg2);
                    Neg <= '0';

                when others =>                  -- Don't care, do nothing
                    Result <= (others => '0');
                    Neg <= '0';

            end case;
        end if;
    end process;

    -- split the 8-bit result into two 4-bit outputs
    R1 <= Result(3 downto 0);    -- lower 4 bits
    R2 <= Result(7 downto 4);    -- upper 4 bits

end calculation;

