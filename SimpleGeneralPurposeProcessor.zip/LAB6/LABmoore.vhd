library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity LABmoore is
    port(
        clk           : in  std_logic;
        data_in       : in  std_logic;
        reset         : in  std_logic;
        student_id    : in  std_logic_vector(8 downto 0); 
        current_state : out std_logic_vector(3 downto 0);
        output_digit  : out std_logic_vector(7 downto 0)
    );
end entity;

architecture fsm of LABmoore is
   
    type state_type is (s0, s1, s2, s3, s4, s5, s6, s7, s8);
    signal yfsm, next_state : state_type;
begin


    process (clk, reset)
    begin
        if reset = '0' then
            yfsm <= s0;
        elsif rising_edge(clk) then
            yfsm <= next_state;
        end if;
    end process;

    
    process (yfsm, data_in)
    begin
        case yfsm is
            when s0 =>
                if data_in = '1' then next_state <= s1; else next_state <= s0; end if;
            when s1 =>
                if data_in = '1' then next_state <= s2; else next_state <= s1; end if;
            when s2 =>
                if data_in = '1' then next_state <= s3; else next_state <= s2; end if;
            when s3 =>
                if data_in = '1' then next_state <= s4; else next_state <= s3; end if;
            when s4 =>
                if data_in = '1' then next_state <= s5; else next_state <= s4; end if;
            when s5 =>
                if data_in = '1' then next_state <= s6; else next_state <= s5; end if;
            when s6 =>
                if data_in = '1' then next_state <= s7; else next_state <= s6; end if;
            when s7 =>
                if data_in = '1' then next_state <= s8; else next_state <= s7; end if;
            when s8 =>
                if data_in = '1' then next_state <= s0; else next_state <= s8; end if;
        end case;
    end process;

    process (yfsm)
    begin
        case yfsm is
            when s0 => output_digit <= "00000101";
            when s1 => output_digit <= "00000000";
            when s2 => output_digit <= "00000001";
            when s3 => output_digit <= "00000010";
            when s4 => output_digit <= "00000110";
            when s5 => output_digit <= "00000011";
            when s6 => output_digit <= "00000111";
            when s7 => output_digit <= "00001000";
            when s8 => output_digit <= "00000011";
        end case;
    end process;

   
    with yfsm select
        current_state <= "0000" when s0,
                         "0001" when s1,
                         "0010" when s2,
                         "0011" when s3,
                         "0100" when s4,
                         "0101" when s5,
                         "0110" when s6,
                         "0111" when s7,
                         "1000" when s8,
                         "1110" when others;

end architecture;