library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity combine16 is
    port(
        b15 : in std_logic;
        b14 : in std_logic;
        b13 : in std_logic;
        b12 : in std_logic;
        b11 : in std_logic;
        b10 : in std_logic;
        b9  : in std_logic;
        b8  : in std_logic;
        b7  : in std_logic;
        b6  : in std_logic;
        b5  : in std_logic;
        b4  : in std_logic;
        b3  : in std_logic;
        b2  : in std_logic;
        b1  : in std_logic;
        b0  : in std_logic;
        vector_out : out std_logic_vector(15 downto 0)
    );
end combine16;

architecture behavioral of combine16 is
begin
    vector_out <= b15 & b14 & b13 & b12 &
                  b11 & b10 & b9  & b8  &
                  b7  & b6  & b5  & b4  &
                  b3  & b2  & b1  & b0;
end behavioral;
	
