library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity converter is
    port(
        din  : in  std_logic_vector(3 downto 0);  -- 4-bit input
        b3   : out std_logic;                     -- MSB
        b2   : out std_logic;
        b1   : out std_logic;
        b0   : out std_logic                      -- LSB
    );
end converter;

architecture behavioral of converter is
begin
    b3 <= din(3);
    b2 <= din(2);
    b1 <= din(1);
    b0 <= din(0);
end behavioral;