library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity LAB6parity is
    port(
        X : in  std_logic_vector(7 downto 0);
        Y : out std_logic;
		  SSEG : out std_logic_vector(6 downto 0 );
        N : out std_logic
    );
end LAB6parity;

architecture Behavioral of LAB6parity is
    signal parity : std_logic;
begin

    parity <= X(7) xor X(6) xor X(5) xor X(4) xor
              X(3) xor X(2) xor X(1) xor X(0);

    process(parity)
    begin
        if parity = '0' then
            Y <= '1';
            N <= '0';
				SSEG <= "1001001";
        else
            Y <= '0';
            N <= '1';
				SSEG <= "0000101";
        end if;
    end process;

end Behavioral;